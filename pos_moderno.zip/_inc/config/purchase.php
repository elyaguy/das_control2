<?php defined('ENVIRONMENT') OR exit('No direct access allowed!');
return array('username'=>'macubeck','purchase_code'=>'d7ea823b-d5a7-4aca-8bb3-2704c7a9c74b');