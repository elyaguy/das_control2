<div id="filemanager">
	<div class="ng-cloak">
	  <angular-filemanager></angular-filemanager>
	</div>
</div>
<script type="text/javascript">
	function pickFileCallback(item) {}
</script>
