<div class="panel panel-default mt-5">
	<div class="panel-body">
		<div class="form-group">
	      <label for="bkash_trx_id" class="col-sm-4 control-label">
	        Card No.
	      </label>
	      <div class="col-sm-8">
	        <input type="text" id="bkash_trx_id" name="payment_details[card_no]" placeholder="Card No" class="form-control" autocomplete="off">
	      </div>
	    </div>
	</div>
</div>