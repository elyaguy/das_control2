<div id="skeleton">
	<div class="skeleton-topbar"></div>
	<div class="skeleton-sidebar"></div>
	<div class="skeleton-left-side"></div>
</div>